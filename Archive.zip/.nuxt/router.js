import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _b5333882 = () => interopDefault(import('../pages/admin/index.vue' /* webpackChunkName: "pages/admin/index" */))
const _63dc2f39 = () => interopDefault(import('../pages/Login/index.vue' /* webpackChunkName: "pages/Login/index" */))
const _9a91a1ec = () => interopDefault(import('../pages/admin/albums/index.vue' /* webpackChunkName: "pages/admin/albums/index" */))
const _63e29c5a = () => interopDefault(import('../pages/admin/bridesmaids-groomsmen/index.vue' /* webpackChunkName: "pages/admin/bridesmaids-groomsmen/index" */))
const _0e204f21 = () => interopDefault(import('../pages/admin/countdown/index.vue' /* webpackChunkName: "pages/admin/countdown/index" */))
const _43b9bf3a = () => interopDefault(import('../pages/admin/couples/index.vue' /* webpackChunkName: "pages/admin/couples/index" */))
const _117081ff = () => interopDefault(import('../pages/admin/events/index.vue' /* webpackChunkName: "pages/admin/events/index" */))
const _66042aa2 = () => interopDefault(import('../pages/admin/guestkbook/index.vue' /* webpackChunkName: "pages/admin/guestkbook/index" */))
const _1b2a9d00 = () => interopDefault(import('../pages/admin/love-story/index.vue' /* webpackChunkName: "pages/admin/love-story/index" */))
const _6fc58aa4 = () => interopDefault(import('../pages/admin/menus/index.vue' /* webpackChunkName: "pages/admin/menus/index" */))
const _e8db4ed6 = () => interopDefault(import('../pages/admin/music/index.vue' /* webpackChunkName: "pages/admin/music/index" */))
const _55cd30a2 = () => interopDefault(import('../pages/admin/sliders/index.vue' /* webpackChunkName: "pages/admin/sliders/index" */))
const _68a2e641 = () => interopDefault(import('../pages/admin/albums/update.vue' /* webpackChunkName: "pages/admin/albums/update" */))
const _c98fb382 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/admin",
    component: _b5333882,
    name: "admin"
  }, {
    path: "/Login",
    component: _63dc2f39,
    name: "Login"
  }, {
    path: "/admin/albums",
    component: _9a91a1ec,
    name: "admin-albums"
  }, {
    path: "/admin/bridesmaids-groomsmen",
    component: _63e29c5a,
    name: "admin-bridesmaids-groomsmen"
  }, {
    path: "/admin/countdown",
    component: _0e204f21,
    name: "admin-countdown"
  }, {
    path: "/admin/couples",
    component: _43b9bf3a,
    name: "admin-couples"
  }, {
    path: "/admin/events",
    component: _117081ff,
    name: "admin-events"
  }, {
    path: "/admin/guestkbook",
    component: _66042aa2,
    name: "admin-guestkbook"
  }, {
    path: "/admin/love-story",
    component: _1b2a9d00,
    name: "admin-love-story"
  }, {
    path: "/admin/menus",
    component: _6fc58aa4,
    name: "admin-menus"
  }, {
    path: "/admin/music",
    component: _e8db4ed6,
    name: "admin-music"
  }, {
    path: "/admin/sliders",
    component: _55cd30a2,
    name: "admin-sliders"
  }, {
    path: "/admin/albums/update",
    component: _68a2e641,
    name: "admin-albums-update"
  }, {
    path: "/",
    component: _c98fb382,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
