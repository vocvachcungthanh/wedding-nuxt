import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const VUEX_PROPERTIES = ['state', 'getters', 'actions', 'mutations']

let store = {};

(function updateModules () {
  store = normalizeRoot(require('../store/index.js'), 'store/index.js')

  // If store is an exported method = classic mode (deprecated)

  // Enforce store modules
  store.modules = store.modules || {}

  resolveStoreModules(require('../store/actions.js'), 'actions.js')
  resolveStoreModules(require('../store/getters.js'), 'getters.js')
  resolveStoreModules(require('../store/mutations.js'), 'mutations.js')
  resolveStoreModules(require('../store/state.js'), 'state.js')
  resolveStoreModules(require('../store/modules/weddings/index.js'), 'modules/weddings/index.js')
  resolveStoreModules(require('../store/modules/uploads/index.js'), 'modules/uploads/index.js')
  resolveStoreModules(require('../store/modules/sliders/index.js'), 'modules/sliders/index.js')
  resolveStoreModules(require('../store/modules/settings/index.js'), 'modules/settings/index.js')
  resolveStoreModules(require('../store/modules/music/index.js'), 'modules/music/index.js')
  resolveStoreModules(require('../store/modules/menus/index.js'), 'modules/menus/index.js')
  resolveStoreModules(require('../store/modules/love-story/index.js'), 'modules/love-story/index.js')
  resolveStoreModules(require('../store/modules/guestkbooks/index.js'), 'modules/guestkbooks/index.js')
  resolveStoreModules(require('../store/modules/events/index.js'), 'modules/events/index.js')
  resolveStoreModules(require('../store/modules/dashboards/index.js'), 'modules/dashboards/index.js')
  resolveStoreModules(require('../store/modules/couples/index.js'), 'modules/couples/index.js')
  resolveStoreModules(require('../store/modules/countdowns/index.js'), 'modules/countdowns/index.js')
  resolveStoreModules(require('../store/modules/BridesmaidsGroomsmen/index.js'), 'modules/BridesmaidsGroomsmen/index.js')
  resolveStoreModules(require('../store/modules/backgrounds/index.js'), 'modules/backgrounds/index.js')
  resolveStoreModules(require('../store/modules/auth/index.js'), 'modules/auth/index.js')
  resolveStoreModules(require('../store/modules/albums/index.js'), 'modules/albums/index.js')
  resolveStoreModules(require('../store/modules/albums/actions.js'), 'modules/albums/actions.js')
  resolveStoreModules(require('../store/modules/albums/getters.js'), 'modules/albums/getters.js')
  resolveStoreModules(require('../store/modules/albums/mutations.js'), 'modules/albums/mutations.js')
  resolveStoreModules(require('../store/modules/albums/state.js'), 'modules/albums/state.js')
  resolveStoreModules(require('../store/modules/auth/actions.js'), 'modules/auth/actions.js')
  resolveStoreModules(require('../store/modules/auth/getters.js'), 'modules/auth/getters.js')
  resolveStoreModules(require('../store/modules/auth/mutations.js'), 'modules/auth/mutations.js')
  resolveStoreModules(require('../store/modules/auth/state.js'), 'modules/auth/state.js')
  resolveStoreModules(require('../store/modules/backgrounds/actions.js'), 'modules/backgrounds/actions.js')
  resolveStoreModules(require('../store/modules/backgrounds/getters.js'), 'modules/backgrounds/getters.js')
  resolveStoreModules(require('../store/modules/backgrounds/mutations.js'), 'modules/backgrounds/mutations.js')
  resolveStoreModules(require('../store/modules/backgrounds/state.js'), 'modules/backgrounds/state.js')
  resolveStoreModules(require('../store/modules/BridesmaidsGroomsmen/actions.js'), 'modules/BridesmaidsGroomsmen/actions.js')
  resolveStoreModules(require('../store/modules/BridesmaidsGroomsmen/getters.js'), 'modules/BridesmaidsGroomsmen/getters.js')
  resolveStoreModules(require('../store/modules/BridesmaidsGroomsmen/mutations.js'), 'modules/BridesmaidsGroomsmen/mutations.js')
  resolveStoreModules(require('../store/modules/BridesmaidsGroomsmen/state.js'), 'modules/BridesmaidsGroomsmen/state.js')
  resolveStoreModules(require('../store/modules/countdowns/actions.js'), 'modules/countdowns/actions.js')
  resolveStoreModules(require('../store/modules/countdowns/getters.js'), 'modules/countdowns/getters.js')
  resolveStoreModules(require('../store/modules/countdowns/mutations.js'), 'modules/countdowns/mutations.js')
  resolveStoreModules(require('../store/modules/countdowns/state.js'), 'modules/countdowns/state.js')
  resolveStoreModules(require('../store/modules/couples/actions.js'), 'modules/couples/actions.js')
  resolveStoreModules(require('../store/modules/couples/getters.js'), 'modules/couples/getters.js')
  resolveStoreModules(require('../store/modules/couples/mutations.js'), 'modules/couples/mutations.js')
  resolveStoreModules(require('../store/modules/couples/state.js'), 'modules/couples/state.js')
  resolveStoreModules(require('../store/modules/dashboards/actions.js'), 'modules/dashboards/actions.js')
  resolveStoreModules(require('../store/modules/dashboards/getters.js'), 'modules/dashboards/getters.js')
  resolveStoreModules(require('../store/modules/dashboards/mutations.js'), 'modules/dashboards/mutations.js')
  resolveStoreModules(require('../store/modules/dashboards/state.js'), 'modules/dashboards/state.js')
  resolveStoreModules(require('../store/modules/events/actions.js'), 'modules/events/actions.js')
  resolveStoreModules(require('../store/modules/events/getters.js'), 'modules/events/getters.js')
  resolveStoreModules(require('../store/modules/events/mutations.js'), 'modules/events/mutations.js')
  resolveStoreModules(require('../store/modules/events/state.js'), 'modules/events/state.js')
  resolveStoreModules(require('../store/modules/guestkbooks/actions.js'), 'modules/guestkbooks/actions.js')
  resolveStoreModules(require('../store/modules/guestkbooks/getters.js'), 'modules/guestkbooks/getters.js')
  resolveStoreModules(require('../store/modules/guestkbooks/mutations.js'), 'modules/guestkbooks/mutations.js')
  resolveStoreModules(require('../store/modules/guestkbooks/state.js'), 'modules/guestkbooks/state.js')
  resolveStoreModules(require('../store/modules/love-story/actions.js'), 'modules/love-story/actions.js')
  resolveStoreModules(require('../store/modules/love-story/getters.js'), 'modules/love-story/getters.js')
  resolveStoreModules(require('../store/modules/love-story/mutations.js'), 'modules/love-story/mutations.js')
  resolveStoreModules(require('../store/modules/love-story/state.js'), 'modules/love-story/state.js')
  resolveStoreModules(require('../store/modules/menus/actions.js'), 'modules/menus/actions.js')
  resolveStoreModules(require('../store/modules/menus/getters.js'), 'modules/menus/getters.js')
  resolveStoreModules(require('../store/modules/menus/mutations.js'), 'modules/menus/mutations.js')
  resolveStoreModules(require('../store/modules/menus/state.js'), 'modules/menus/state.js')
  resolveStoreModules(require('../store/modules/music/actions.js'), 'modules/music/actions.js')
  resolveStoreModules(require('../store/modules/music/getters.js'), 'modules/music/getters.js')
  resolveStoreModules(require('../store/modules/music/mutations.js'), 'modules/music/mutations.js')
  resolveStoreModules(require('../store/modules/music/state.js'), 'modules/music/state.js')
  resolveStoreModules(require('../store/modules/settings/actions.js'), 'modules/settings/actions.js')
  resolveStoreModules(require('../store/modules/settings/getters.js'), 'modules/settings/getters.js')
  resolveStoreModules(require('../store/modules/settings/mutations.js'), 'modules/settings/mutations.js')
  resolveStoreModules(require('../store/modules/settings/state.js'), 'modules/settings/state.js')
  resolveStoreModules(require('../store/modules/sliders/actions.js'), 'modules/sliders/actions.js')
  resolveStoreModules(require('../store/modules/sliders/getters.js'), 'modules/sliders/getters.js')
  resolveStoreModules(require('../store/modules/sliders/mutations.js'), 'modules/sliders/mutations.js')
  resolveStoreModules(require('../store/modules/sliders/state.js'), 'modules/sliders/state.js')
  resolveStoreModules(require('../store/modules/uploads/actions.js'), 'modules/uploads/actions.js')
  resolveStoreModules(require('../store/modules/uploads/getters.js'), 'modules/uploads/getters.js')
  resolveStoreModules(require('../store/modules/uploads/mutations.js'), 'modules/uploads/mutations.js')
  resolveStoreModules(require('../store/modules/uploads/state.js'), 'modules/uploads/state.js')
  resolveStoreModules(require('../store/modules/weddings/actions.js'), 'modules/weddings/actions.js')
  resolveStoreModules(require('../store/modules/weddings/getters.js'), 'modules/weddings/getters.js')
  resolveStoreModules(require('../store/modules/weddings/mutations.js'), 'modules/weddings/mutations.js')
  resolveStoreModules(require('../store/modules/weddings/state.js'), 'modules/weddings/state.js')

  // If the environment supports hot reloading...
})()

// createStore
export const createStore = store instanceof Function ? store : () => {
  return new Vuex.Store(Object.assign({
    strict: (process.env.NODE_ENV !== 'production')
  }, store))
}

function normalizeRoot (moduleData, filePath) {
  moduleData = moduleData.default || moduleData

  if (moduleData.commit) {
    throw new Error(`[nuxt] ${filePath} should export a method that returns a Vuex instance.`)
  }

  if (typeof moduleData !== 'function') {
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData)
  }
  return normalizeModule(moduleData, filePath)
}

function normalizeModule (moduleData, filePath) {
  if (moduleData.state && typeof moduleData.state !== 'function') {
    console.warn(`'state' should be a method that returns an object in ${filePath}`)

    const state = Object.assign({}, moduleData.state)
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData, { state: () => state })
  }
  return moduleData
}

function resolveStoreModules (moduleData, filename) {
  moduleData = moduleData.default || moduleData
  // Remove store src + extension (./foo/index.js -> foo/index)
  const namespace = filename.replace(/\.(js|mjs)$/, '')
  const namespaces = namespace.split('/')
  let moduleName = namespaces[namespaces.length - 1]
  const filePath = `store/${filename}`

  moduleData = moduleName === 'state'
    ? normalizeState(moduleData, filePath)
    : normalizeModule(moduleData, filePath)

  // If src is a known Vuex property
  if (VUEX_PROPERTIES.includes(moduleName)) {
    const property = moduleName
    const propertyStoreModule = getStoreModule(store, namespaces, { isProperty: true })

    // Replace state since it's a function
    mergeProperty(propertyStoreModule, moduleData, property)
    return
  }

  // If file is foo/index.js, it should be saved as foo
  const isIndexModule = (moduleName === 'index')
  if (isIndexModule) {
    namespaces.pop()
    moduleName = namespaces[namespaces.length - 1]
  }

  const storeModule = getStoreModule(store, namespaces)

  for (const property of VUEX_PROPERTIES) {
    mergeProperty(storeModule, moduleData[property], property)
  }

  if (moduleData.namespaced === false) {
    delete storeModule.namespaced
  }
}

function normalizeState (moduleData, filePath) {
  if (typeof moduleData !== 'function') {
    console.warn(`${filePath} should export a method that returns an object`)
    const state = Object.assign({}, moduleData)
    return () => state
  }
  return normalizeModule(moduleData, filePath)
}

function getStoreModule (storeModule, namespaces, { isProperty = false } = {}) {
  // If ./mutations.js
  if (!namespaces.length || (isProperty && namespaces.length === 1)) {
    return storeModule
  }

  const namespace = namespaces.shift()

  storeModule.modules[namespace] = storeModule.modules[namespace] || {}
  storeModule.modules[namespace].namespaced = true
  storeModule.modules[namespace].modules = storeModule.modules[namespace].modules || {}

  return getStoreModule(storeModule.modules[namespace], namespaces, { isProperty })
}

function mergeProperty (storeModule, moduleData, property) {
  if (!moduleData) {
    return
  }

  if (property === 'state') {
    storeModule.state = moduleData || storeModule.state
  } else {
    storeModule[property] = Object.assign({}, storeModule[property], moduleData)
  }
}
