const middleware = {}

middleware['admin'] = require('../middleware/admin.js')
middleware['admin'] = middleware['admin'].default || middleware['admin']

middleware['login'] = require('../middleware/login.js')
middleware['login'] = middleware['login'].default || middleware['login']

middleware['mobile'] = require('../middleware/mobile.js')
middleware['mobile'] = middleware['mobile'].default || middleware['mobile']

export default middleware
